Fixture Builder for Inventor 2026.11.27.2

1. Start Inventor (with your metric part and assembly templates).
2. Double-click Run.bat in this folder.
3. Wait 10 to 30 minutes and leave Inventor alone. When it is done, Explorer shows the zip
   (named Inventor-<version>-<build>.zip, in C:\Users\Public\FixtureOut). Send it to Dutchy in a Discord direct message.

Nothing is installed and no admin rights are needed. The results go in C:\Users\Public\FixtureOut, outside
your user profile so that no file carries your name. Delete that folder and this one when you are done.

If Windows asks "Do you want to run this file?", choose Run. (Right-click the downloaded zip, Properties,
Unblock, before unzipping, avoids the question.)

Guide: https://fixtures.dutchmancad.xyz/builders/inventor/
