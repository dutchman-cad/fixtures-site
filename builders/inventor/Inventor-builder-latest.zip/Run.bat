@echo off
rem Fixture Builder for Inventor: double-click this file. No install, no admin rights.
rem Everything it writes goes in C:\Users\Public\FixtureOut (outside your user profile, so no file carries your name), apart from what Inventor itself writes.
setlocal EnableExtensions
title Fixture Builder for Inventor
chcp 65001 >nul
set "RC=0"
pushd "%~dp0"
if errorlevel 1 goto :incomplete
set "HERE=%~dp0"
set "PYEXE=%HERE%python\python.exe"
set "SCRIPT=%HERE%build_inventor.py"
set "OUT=%PUBLIC%\FixtureOut"
set "NOTE=%PUBLIC%\FixtureOut\last-run.txt"

echo.
echo   Fixture Builder for Inventor
echo   ----------------------------
echo.

if not exist "%PYEXE%" goto :incomplete
if not exist "%SCRIPT%" goto :incomplete

tasklist /FI "IMAGENAME eq Inventor.exe" /NH 2>nul | find /I "Inventor.exe" >nul
if errorlevel 1 goto :noinventor

if not exist "%OUT%" mkdir "%OUT%"
echo   Inventor is running. Building the fixtures now.
echo   This takes roughly 10 to 30 minutes. Please leave Inventor alone until it is done.
echo   Nothing more is shown until the end; that is normal.
echo.

"%PYEXE%" -B -X utf8 "%SCRIPT%" "%OUT%" > "%NOTE%" 2>&1
set "CODE=%errorlevel%"

set "LAST="
for /f "usebackq delims=" %%L in ("%NOTE%") do set "LAST=%%L"

echo   ----------------------------
type "%NOTE%"
echo.
if not "%CODE%"=="0" goto :failed
if not defined LAST goto :failed
if /I not "%LAST:~-4%"==".zip" goto :failed
if not exist "%LAST%" goto :failed

echo   Done. Your zip is the file shown in the window that opens now.
echo   Send it to Dutchy in a Discord direct message.
explorer /select,"%LAST%"
goto :end

:failed
set "RC=1"
echo   The builder did not finish cleanly. The text above says why.
echo   It is also saved as last-run.txt in C:\Users\Public\FixtureOut.
echo   Please send that file to Dutchy in a Discord direct message.
goto :end

:noinventor
set "RC=1"
echo   Start Inventor first, then run this again.
goto :end

:incomplete
set "RC=1"
echo   This folder is not complete. Please unzip the whole download first:
echo   right-click the zip, choose Extract All, then open Run.bat from the new folder.
goto :end

:end
echo.
pause
popd
endlocal & exit /b %RC%
